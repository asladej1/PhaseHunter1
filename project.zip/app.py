# Import your Game class
from game import Game
from phrase import Phrase

# Create your Dunder Main statement.
if __name__ == '__main__':
    
        
    game = Game()
    print(game.active_phrase.phrase) 
    game.start()
    

